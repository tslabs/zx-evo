#ifndef _T_PS2K_H
#define _T_PS2K_H

void Test_PS2Keyb(void);

#endif
