#ifndef _T_DRAM_H
#define _T_DRAM_H

#include "_types.h"

void Test_DRAM(u8 callflag);

#endif
