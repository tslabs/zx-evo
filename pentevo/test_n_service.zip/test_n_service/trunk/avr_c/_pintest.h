#ifndef _PINTEST_H
#define _PINTEST_H

#include "_types.h"

void PinTest(void);

#endif
