#ifndef _T_SD_H
#define _T_SD_H

void Test_SD_MMC(void);

#endif
