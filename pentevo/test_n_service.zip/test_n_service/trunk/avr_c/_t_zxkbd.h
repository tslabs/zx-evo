#ifndef _T_ZXKBD_H
#define _T_ZXKBD_H

void Test_ZXKeyb(void);

#endif
