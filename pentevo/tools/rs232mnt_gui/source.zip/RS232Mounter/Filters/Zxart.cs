﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using Newtonsoft.Json;

namespace RS232Mounter.Filters
{
    internal class Zxart
    {
        private class APIResponse
        {
            public ContentCollection responseData;
        }

        private class ContentCollection
        {
            public ZXMusic[] zxMusic;
            public ZXPicture[] zxPicture;
        }

        private class ZXMusic
        {
                public int id;
                public string structureType;
                public string title;
                public string time;
                public string compo;
                public string year;
                public string partyplace;
                public string url;
                public string votes;
                public string[] authorIds;
                public string originalUrl;
        }

        private class ZXPicture
        {
            public int id;
            public string structureType;
            public string title;
            public string url;
            public string imageUrl;
            public string originalUrl;
        }

        internal static IEnumerable<string> Filter(string fileName)
        {
            List<string> result = new List<string>();
            if (System.Text.RegularExpressions.Regex.IsMatch(fileName, "http://zxart\\.ee/api/.*"))
            {
                byte[] apiResponse;
                using (System.Net.WebClient client = new System.Net.WebClient())
                    apiResponse = client.DownloadData(fileName);
                APIResponse response = JsonConvert.DeserializeObject<APIResponse>(System.Text.Encoding.UTF8.GetString(apiResponse));
                if (response != null && response.responseData != null)
                {
                    if (response.responseData.zxMusic != null)
                        foreach (ZXMusic prod in response.responseData.zxMusic)
                            result.Add(prod.originalUrl);
                    if (response.responseData.zxPicture != null)
                        foreach (ZXPicture prod in response.responseData.zxPicture)
                            result.Add(prod.originalUrl);
                }
            }
            return result;
        }
    }
}
