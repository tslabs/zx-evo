﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RS232Mounter.Filters
{
    internal class FilterManager
    {
        internal static IEnumerable<string> Filter(IEnumerable<string> fileNames)
        {
            List<string> result = new List<string>();
            foreach (string fileName in fileNames)
            {
                if (!System.Text.RegularExpressions.Regex.IsMatch(fileName, "http:[\\\\/]{2}"))
                    result.Add(fileName);
                else
                {
                    List<string> filterResult = new List<string>();
                    filterResult.AddRange(Zxart.Filter(fileName));
                    if (filterResult.Count > 0)
                        result.AddRange(filterResult);
                    else
                        result.Add(fileName);
                }
            }
            return result;
        }
    }
}
