﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace RS232Mounter
{
    internal class FileCache : IDisposable
    {
        private struct FileInfo
        {
            internal string OriginalFileName;
            internal string LocalFileName;
            internal bool Downloaded;
        }

        private List<FileInfo> fileInfo = new List<FileInfo>();

        internal FileCache(string[] fileNames)
        {
            if (fileNames == null || fileNames.Length == 0) return;
            IEnumerable<string> filteredFileNames = Filters.FilterManager.Filter(fileNames);
            foreach (string fileName in filteredFileNames)
            {
                FileInfo currentFileInfo = new FileInfo() { OriginalFileName = fileName, LocalFileName = fileName, Downloaded = false };
                if (System.Text.RegularExpressions.Regex.IsMatch(fileName, "http:[\\\\/]{2}.*"))
                {
                    string localFileName = Path.GetFileName(System.Web.HttpUtility.UrlDecode(fileName));
                    string localFilePath = Path.Combine(Path.GetTempPath(), localFileName);
                    if (localFileName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || Directory.Exists(localFilePath) || File.Exists(localFilePath))
                        localFilePath = Path.Combine(Path.GetTempPath(), string.Format("{0}.tmp", Guid.NewGuid().ToString()));
                    using (System.Net.WebClient webClient = new System.Net.WebClient())
                        webClient.DownloadFile(new Uri(fileName), localFilePath);
                    currentFileInfo.Downloaded = true;
                    currentFileInfo.LocalFileName = localFilePath;
                }
                fileInfo.Add(currentFileInfo);
            }
        }

        internal string[] GetOriginalFileNames()
        {
            List<string> result = new List<string>();
            foreach (FileInfo currentFileInfo in fileInfo)
                result.Add(currentFileInfo.OriginalFileName);
            return result.ToArray();
        }

        internal string[] GetLocalFileNames()
        {
            List<string> result = new List<string>();
            foreach (FileInfo currentFileInfo in fileInfo)
                result.Add(currentFileInfo.LocalFileName);
            return result.ToArray();
        }

        internal string GetOriginalFileNamesSingleLine()
        {
            return string.Join(Environment.NewLine, GetOriginalFileNames());
        }

        internal void Clear()
        {
            foreach (FileInfo currentFileInfo in fileInfo)
                if (currentFileInfo.Downloaded && File.Exists(currentFileInfo.LocalFileName))
                    File.Delete(currentFileInfo.LocalFileName);
        }

        public void Dispose()
        {
            Clear();
        }
    }
}
