﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace RS232Mounter.TSConfCommunication
{
    enum State
    {
        IDLE,
        RECEIVE_DATA
    }

    static class Consts
    {
        internal static class Signatures
        {
            internal static class Request
            {
                internal const byte First = 0xaa;
                internal const byte Second = 0x55;
            }

            internal static class Sector
            {
                internal const byte First = 0xcc;
                internal const byte Second = 0xee;
            }
        }

        internal static class OpCodes
        {
            internal const int Read = 0x05;
            internal const int Write = 0x06;
        }
    }

}
