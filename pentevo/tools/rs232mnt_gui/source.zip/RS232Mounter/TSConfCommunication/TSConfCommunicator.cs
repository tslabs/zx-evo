﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO.Ports;
using System.Windows.Forms;
using System.Threading;

namespace RS232Mounter.TSConfCommunication
{
    class TSConfCommunicator : IDisposable
    {
        private SerialPort port;
        private Thread communicationThread;
        private AutoResetEvent terminateThread = new AutoResetEvent(false);

        private void SetupPort()
        {
            port = new SerialPort();
            port.BaudRate = 115200;
            
            port.DataBits = 8;
            port.DiscardNull = false;
            port.DtrEnable = false;
            port.Encoding = Encoding.Default;
            port.Handshake = Handshake.None;
            port.Parity = Parity.None;
            port.ReadBufferSize = 512;
            port.RtsEnable = false;
            port.StopBits = StopBits.One;
            port.WriteBufferSize = 512;
            port.WriteBufferSize = 512;

            port.ReadTimeout = 500;
            port.WriteTimeout = 500;

        }

        private byte CalculateCRC(byte[] data, int offset, int length, byte initialValue = 0)
        {
            for (int i = offset; i < (offset + length); i++)
                initialValue ^= data[i];
            return initialValue;
        }

        private int ReadFromPort(byte[] data, int offset, int count)
        {
            int totalRead = 0;
            while (count > 0)
            {
                var bytesRead = ReadDataFromPort(data, offset, count);
                totalRead += bytesRead;
                offset += bytesRead;
                count -= bytesRead;
            }
            return totalRead;
        }

        private int ReadDataFromPort(byte[] data, int offset, int count)
        {
            IAsyncResult asyncResult = port.BaseStream.BeginRead(data, offset, count, null, null);
            int signalledHandleIndex = WaitHandle.WaitAny(new WaitHandle[] { asyncResult.AsyncWaitHandle, terminateThread }, -1);
            if (signalledHandleIndex == 1) { System.Diagnostics.Debug.WriteLine("Read byte: thread aborted"); Thread.CurrentThread.Abort(); }
            int bytesRead = port.BaseStream.EndRead(asyncResult);
            if (!asyncResult.IsCompleted)
                throw new System.IO.IOException("No such data to read");
            return bytesRead;
        }

        private byte ReadByteFromPort()
        {
            byte[] result = new byte[1];
            ReadFromPort(result, 0, 1);
            return result[0];
        }

        private void Log(string message)
        {
            RS232Mounter.log.WriteLine(message);
        }

        private void Log(int drive, int operation, int track, int sector)
        {
            Log(string.Format("Drv: {0}, Op: {1}, Trk:{2}, Sec: {3}", (char)(drive + (int)'A'), operation == 5 ? "R" : operation == 6 ? "W" : "?", track, sector));
        }

        private void CommunicationRoutine()
        {
            try
            {
                while (true)
                {
                    byte readByte;
                    if ((readByte = ReadByteFromPort()) != Consts.Signatures.Request.First) { Log(string.Format("Error: invalid request signature first byte: {0}", readByte)); continue; }
                    if ((readByte = ReadByteFromPort()) != Consts.Signatures.Request.Second) { Log(string.Format("Error: invalid request signature second byte: {0}", readByte)); continue; }
                    int driveIndex = ReadByteFromPort() & 0x03;
                    int opcode = ReadByteFromPort();
                    if (opcode != Consts.OpCodes.Read && opcode != Consts.OpCodes.Write) { Log(string.Format("Error: invalid opcode: {0}", opcode)); continue; }
                    int track = ReadByteFromPort();
                    int sector = ReadByteFromPort() & 0x0f;
                    readByte = ReadByteFromPort();

                    switch (opcode)
                    {
                        case Consts.OpCodes.Read:
                            {
                                int sectorSize = RS232Mounter.diskController.GetSectorSize(driveIndex);
                                byte[] data = new byte[sectorSize + 3];
                                data[0] = Consts.Signatures.Sector.First;
                                data[1] = Consts.Signatures.Sector.Second;
                                Array.Clear(data, 2, sectorSize);
                                if (RS232Mounter.diskController.IsMounted(driveIndex))
                                    if (!RS232Mounter.diskController.Read(driveIndex, track, sector, data, 2))
                                        Log("Error: Some image read error");
                                    else ;
                                else
                                    Log("Error: drive is dismounted");
                                data[data.Length - 1] = CalculateCRC(data, 0, data.Length - 1);
                                port.Write(data, 0, data.Length);
                                Log(driveIndex, opcode, track, sector);
                                break;
                            };
                        case Consts.OpCodes.Write:
                            {
                                int sectorSize = RS232Mounter.diskController.GetSectorSize(driveIndex);
                                byte[] data = new byte[sectorSize + 1];
                                var bytesReceived = ReadFromPort(data, 0, data.Length);
                                if (bytesReceived == data.Length)
                                {
                                    if (data[data.Length - 1] == CalculateCRC(data, 0, data.Length - 1))
                                        RS232Mounter.diskController.Write(driveIndex, track, sector, data, 0);
                                    else
                                        Log("Error: Invalid sector CRC");
                                    Log(driveIndex, opcode, track, sector);
                                }
                                else
                                    Log($"Error: Expected bytes to read: {data.Length}, Received bytes: {bytesReceived}");
                                break;
                            };
                        default: { Log(string.Format("Error: Invalid opcode: {0}", opcode)); break; }
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.GetType() != typeof(ThreadAbortException))
                    Log(string.Format("Error: an exception occurred: {0}", ex.Message));
                else
                    System.Diagnostics.Debug.WriteLine("Communication thread is aborted");
            }

        }

        private void CloseConnection()
        {
            if (communicationThread != null)
            {
                terminateThread.Set();
                if (!communicationThread.Join(TimeSpan.FromSeconds(10))) { Log("Warning: Timeout waiting of disconnect"); communicationThread.Abort(); }
            }
            communicationThread = null;
            if (port.IsOpen) port.Close();

        }

        private void OpenConnection()
        {
            port.Open();
            terminateThread.Reset();
            communicationThread = new Thread(new ThreadStart(CommunicationRoutine));
            communicationThread.Start();
        }

        internal TSConfCommunicator()
        {
            SetupPort();
            string portName = Properties.Settings.Default.CurrentCOMPort;
            try
            {
                if (string.IsNullOrEmpty(portName))
                    MessageBox.Show("COM Port name is unpecified. Please select port via tray icon menu", "RS232 Mounter", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    SelectPort(portName);
            }
            catch(Exception ex)
            {
                Properties.Settings.Default.CurrentCOMPort = null;
                OnFailedOpenPort(ex.Message);
            }
        }

        private void OnFailedOpenPort(string exceptionMessage)
        {
            try
            {
                CloseConnection();
            }
            catch (Exception ex)
            {
                if (port.IsOpen) port.Close();
            }
            string message = string.Format("Error: Open COM Port failed: {00}", exceptionMessage);
            Log(message);
            MessageBox.Show(message, "Open COM POrt", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        internal static string[] GetCOMPorts()
        {
            return SerialPort.GetPortNames();
        }

        internal bool SelectPort(string portName)
        {
            try
            {
                CloseConnection();
                port.PortName = portName;
                OpenConnection();
                return true;
            }
            catch(Exception ex)
            {
                OnFailedOpenPort(ex.Message);
                return false;
            }
        }

        public void Dispose()
        {
            CloseConnection();
            port.Dispose();
            port = null;
        }
    }
}
