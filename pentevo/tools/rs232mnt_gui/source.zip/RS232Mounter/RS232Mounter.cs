﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using RS232Mounter.UI;

namespace RS232Mounter
{
    static class RS232Mounter
    {
        internal static Log log = new Log();
        internal static DiskController diskController = new DiskController();
        internal static TSConfCommunication.TSConfCommunicator TSConfCommunicator = new TSConfCommunication.TSConfCommunicator();
        internal static DropForm dropForm = new DropForm();

        [STAThread]
        static void Main()
        {
            TrayIcon icon = new TrayIcon();
            Application.ApplicationExit += (Senter, EventArgs) =>
                {
                    diskController.Dispose();
                    TSConfCommunicator.Dispose();
                    Properties.Settings.Default.Save();
                };
            Application.Run();
        }
    }
}
