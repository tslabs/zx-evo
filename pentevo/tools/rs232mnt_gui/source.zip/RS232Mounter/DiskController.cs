﻿using System;
using System.Collections.Generic;
using System.Text;
using RS232Mounter.ImageFormatProviders.BaseClasses;
using RS232Mounter.ImageFormatProviders.Helpers;

namespace RS232Mounter
{
    class DiskController : IDisposable
    {
        private ImageFormatProviderBase[] drives = new ImageFormatProviderBase[4];

        internal bool Mount(int driveIndex, string fileName) { return Mount(driveIndex, new string[] { fileName }); }

        internal bool Mount(int driveIndex, string[] fileNames)
        {
            try
            {
                if (driveIndex < 0 || driveIndex > 3) return false;
                FileCache fileCache = new FileCache(fileNames);
                ImageFormatProviderBase drive = drives[driveIndex];
                if (drive != null && drive.IsMounted)
                    if (string.Compare(string.Join(Environment.NewLine, drive.FileNames), fileCache.GetOriginalFileNamesSingleLine(), true) == 0)
                        return true;
                ImageFormatProviderBase provider = ImageProviderFactory.GetProviderForFile(fileCache.GetLocalFileNames());
                if (provider == null) return false;
                if (!provider.Mount(fileCache)) return false;
                if (drive != null)
                {
                    if (drive.IsMounted) drive.Dismount();
                    drive.Dispose();
                }
                drives[driveIndex] = provider;
                return true;
            }
            catch(Exception ex)
            {
                RS232Mounter.log.WriteLine(string.Format("Error: Mounting failed: {0}", ex.Message));
                return false;
            }
        }

        internal void Dismount(int driveIndex)
        {
            if (driveIndex < 0 || driveIndex > 3) return;
            if (drives[driveIndex].IsMounted)
                drives[driveIndex].Dismount();
            drives[driveIndex].Dispose();
            drives[driveIndex] = null;
        }

        internal bool Read(int driveIndex, int track, int sector, byte[] data, int offset)
        {
            if (driveIndex < 0 || driveIndex > 3 || drives[driveIndex] == null || !drives[driveIndex].IsMounted) return false;
            return drives[driveIndex].Read(track, sector, data, offset);
        }

        internal int GetSectorSize(int driveIndex)
        {
            if (driveIndex < 0 || driveIndex > 3 || drives[driveIndex] == null || !drives[driveIndex].IsMounted) return 0;
            return drives[driveIndex].GetSectorSize();
        }

        internal void Write(int driveIndex, int track, int sector, byte[] data, int offset)
        {
            if (driveIndex < 0 || driveIndex > 3 || drives[driveIndex] == null || !drives[driveIndex].IsMounted) return;
            drives[driveIndex].Write(track, sector, data, offset);
        }

        internal bool IsMounted(int driveIndex)
        {
            if (driveIndex < 0 || driveIndex > 3 || drives[driveIndex] == null) return false;
            return drives[driveIndex].IsMounted;
        }

        internal string[] GetDriveFileNames(int driveIndex)
        {
            if (driveIndex < 0 || driveIndex > 3 || drives[driveIndex] == null) return null;
            return drives[driveIndex].FileNames;
        }

        internal DiskController()
        {
            Mount(0, Properties.Settings.Default.DriveImage0);
            Mount(1, Properties.Settings.Default.DriveImage1);
            Mount(2, Properties.Settings.Default.DriveImage2);
            Mount(3, Properties.Settings.Default.DriveImage3);
        }



        public void Dispose()
        {
            for (int i = 0; i < 3; i++)
                if (drives[i] != null && drives[i].IsMounted) drives[i].Dismount();
        }
    }
}
