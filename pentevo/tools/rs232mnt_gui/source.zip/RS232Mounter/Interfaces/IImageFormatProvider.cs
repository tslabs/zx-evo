﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RS232Mounter
{
    abstract class IImageFormatProviderBase : IDisposable
    {
        internal abstract bool Mount(string fileName);
        internal abstract void Dismount();
        internal static bool CheckFormat(string fileName) { return false; }
        internal abstract bool IsMounted { get; }
        internal abstract byte[] Read(int track, int sector);
        internal abstract void Write(int track, int sector, byte[] data);
        internal abstract string FileName { get; }
        public abstract void Dispose();
    }
}
