﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace RS232Mounter.UI
{
    public partial class DropForm : Form
    {
        private Point mouseOverCoords;
        private Color letterColor = Color.Gray;
        private const int PADDING = 2;

        public DropForm()
        {
            InitializeComponent();
            SetStyle(ControlStyles.ResizeRedraw, true);
            Visible = Properties.Settings.Default.ShowDropForm;
        }

        #region Behavior

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        private enum WM : int
        {
            MOVING = 0x216,
            SIZING = 0x214
        }
        protected override void WndProc(ref Message m)
        {
            if (/*m.Msg == (int)WM.MOVING || */m.Msg == (int)WM.SIZING)
            {
                int verticalBordersWidth = Width - ClientSize.Width;
                int horizontalBorderHeight = Height - ClientSize.Height;
                RECT rectangle = (RECT)Marshal.PtrToStructure(m.LParam, typeof(RECT));
                int width = rectangle.Right - rectangle.Left - verticalBordersWidth;
                int height = rectangle.Bottom - rectangle.Top - horizontalBorderHeight;
                int maxSize = width > height ? width : height;
                rectangle.Bottom = rectangle.Top + maxSize + horizontalBorderHeight;
                rectangle.Right = rectangle.Left + maxSize + verticalBordersWidth;
                Marshal.StructureToPtr(rectangle, m.LParam, false);
                return;
            }
            base.WndProc(ref m);
        }

        private void DropForm_VisibleChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default.ShowDropForm = (sender as DropForm).Visible;
        }

        private void DropForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                (sender as DropForm).Hide();
            }
            else
            {
                Properties.Settings.Default.DropFormLocation = Location;
                Properties.Settings.Default.DropFormSize = Size;
            }
            
        }

        private void DropForm_Load(object sender, EventArgs e)
        {
            Location = Properties.Settings.Default.DropFormLocation;
            Size = Properties.Settings.Default.DropFormSize;
        }

        #endregion

        #region Painting

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            int size = e.ClipRectangle.Width;
            int cellSize = size / 2;

            int iconRectSize = (cellSize * 3 / 4) - 2 * PADDING;

            int iconsize = iconRectSize < 24 ? 16 :
                iconRectSize < 32 ? 24 :
                iconRectSize < 48 ? 32 :
                iconRectSize < 64 ? 48 :
                iconRectSize < 72 ? 64 :
                iconRectSize < 96 ? 72 :
                iconRectSize < 128 ? 96 : 128;

            int cellIconOffset = (iconRectSize - iconsize) / 2 + PADDING + cellSize / 4;
            for (int i = 0; i < 4; i++)
            {
                int cellDisplaceX = (i % 2) * cellSize;
                int cellDisplaceY = (i / 2) * cellSize;

                if (RS232Mounter.diskController.IsMounted(i))
                    e.Graphics.FillRectangle(Brushes.DarkRed, new Rectangle(cellDisplaceX, cellDisplaceY, cellSize, cellSize));

                Icon displayIcon = RS232Mounter.diskController.IsMounted(i) ? Properties.Resources.MountedDrive : Properties.Resources.EmptyDrive;
                e.Graphics.DrawIcon(new Icon(displayIcon, new Size(iconsize, iconsize)), cellIconOffset + cellDisplaceX, cellIconOffset + cellDisplaceY);
            }
            PaintLetters(e.Graphics);

            Pen separatorPen = new Pen(Color.White);
            e.Graphics.DrawLine(separatorPen, 0, cellSize, size, cellSize);
            e.Graphics.DrawLine(separatorPen, cellSize, 0, cellSize, size);
        }

        private void PaintLetters(Graphics graphics = null)
        {
            graphics = graphics ?? Graphics.FromHwnd(this.Handle);
            int cellSize = ClientSize.Width / 2;
            int mouseOverDriveIndex = mouseOverCoords.IsEmpty ? -1 : (mouseOverCoords.X > cellSize ? 1 : 0) + (mouseOverCoords.Y > cellSize ? 2 : 0);
            for (int i = 0; i < 4; i++)
            {
                int cellDisplaceX = (i % 2) * cellSize;
                int cellDisplaceY = (i / 2) * cellSize;
                Color c = (i == mouseOverDriveIndex) ? letterColor : Color.Gray;
                graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SingleBitPerPixelGridFit;
                graphics.DrawString(((char)((int)'A' + i)).ToString(),
                    new Font(Font.FontFamily, cellSize / 4, Font.Style),
                    new SolidBrush(c),
                    PADDING + cellDisplaceX,
                    PADDING + cellDisplaceY);
            }
        }

        #endregion

        #region Mouse Movements

        private void DropForm_MouseLeave(object sender, EventArgs e)
        {
            mouseOverCoords = Point.Empty;
            letterColor = Color.White;
            PaintLetters();
        }

        private void DropForm_MouseMove(object sender, MouseEventArgs e)
        {
            int cellSize = ClientSize.Width / 2;
            int oldDriveindex = (mouseOverCoords.X > cellSize ? 1 : 0) + (mouseOverCoords.Y > cellSize ? 2 : 0);

            mouseOverCoords.X = e.X;
            mouseOverCoords.Y = e.Y;
            letterColor = Color.White;
            PaintLetters();

            int newDriveIndex = (mouseOverCoords.X > cellSize ? 1 : 0) + (mouseOverCoords.Y > cellSize ? 2 : 0);

            if (oldDriveindex != newDriveIndex)
            {
                string toolTipText;
                if (!RS232Mounter.diskController.IsMounted(newDriveIndex))
                    toolTipText = "Dismounted";
                else
                {
                    string[] mountedFileNames = RS232Mounter.diskController.GetDriveFileNames(newDriveIndex);
                    if (mountedFileNames.Length > 1)
                        toolTipText = "Multiple files";
                    else
                        toolTipText = mountedFileNames[0];
                }
                toolTip.SetToolTip(this, toolTipText);
            }
        }

        #endregion

        #region Drag and drop

        private void DropForm_DragDrop(object sender, DragEventArgs e)
        {
            string[] fileNames = null;
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                fileNames = (string[])e.Data.GetData(DataFormats.FileDrop);
            else
                if (e.Data.GetDataPresent(DataFormats.Text))
                    fileNames = e.Data.GetData(DataFormats.Text).ToString().Split(new [] { Environment.NewLine, "\n" }, StringSplitOptions.RemoveEmptyEntries);
                else
                    return;
            int cellSize = ClientSize.Width / 2;
            Point windowMouseCoords = PointToClient(new Point(e.X, e.Y));
            int mouseOverDriveIndex = (windowMouseCoords.X > cellSize ? 1 : 0) + (windowMouseCoords.Y > cellSize ? 2 : 0);
            RS232Mounter.diskController.Mount(mouseOverDriveIndex, fileNames);
            Invalidate();
        }

        private void DropForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop) || e.Data.GetDataPresent(DataFormats.Text)) e.Effect = DragDropEffects.Copy;
        }

        private void DropForm_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                letterColor = Color.LightGreen;
                mouseOverCoords = PointToClient(new Point(e.X, e.Y));
                PaintLetters();
            }
        }

        #endregion

        #region Actions

        private void DropForm_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int cellSize = ClientSize.Width / 2;
            int mouseOverDriveIndex = ((e as MouseEventArgs).X > cellSize ? 1 : 0) + ((e as MouseEventArgs).Y > cellSize ? 2 : 0);
            if (RS232Mounter.diskController.IsMounted(mouseOverDriveIndex))
                MountContextMenu.Dismount(mouseOverDriveIndex);
            else
                if (Clipboard.ContainsText())
                {
                    RS232Mounter.diskController.Mount(mouseOverDriveIndex, Clipboard.GetText(TextDataFormat.Text).Split(new string[] { Environment.NewLine, "\n" }, StringSplitOptions.RemoveEmptyEntries));
                    Invalidate();
                }
        }

        private void contextMenu_Opening(object sender, CancelEventArgs e)
        {
            ContextMenuStrip menu = sender as ContextMenuStrip;
            int cellSize = ClientSize.Width / 2;
            Point windowMouseCoords = PointToClient(new Point(menu.Left, menu.Top));
            int mouseOverDriveIndex = (windowMouseCoords.X > cellSize ? 1 : 0) + (windowMouseCoords.Y > cellSize ? 2 : 0);
            MountContextMenu.FillMountMenu((sender as ContextMenuStrip).Items, mouseOverDriveIndex);
        }

        #endregion
    }
}
