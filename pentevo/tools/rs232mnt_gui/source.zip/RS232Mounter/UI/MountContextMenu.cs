﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace RS232Mounter.UI
{
    internal static class MountContextMenu
    {
        internal static void FillMountMenu(ToolStripItemCollection items, int driveIndex)
        {
            bool anyRecentFiles = Properties.Settings.Default.RecentImages.Count > 0;
            string[] currentMountedFiles = RS232Mounter.diskController.GetDriveFileNames(driveIndex);
            string currentMountedFile = (currentMountedFiles != null && currentMountedFiles.Length == 1) ? currentMountedFiles[0] : null;
            
            items.Clear();
            items.Add(new ToolStripMenuItem("Mount Files...", null, OnMountFiles) { Tag = driveIndex });
            items.Add(new ToolStripMenuItem("Mount Directory...", null, OnMountDirectory) { Tag = driveIndex });
            items.Add(new ToolStripMenuItem("Mount from Clipboard", null, OnMountFromClipboard) { Tag = driveIndex });
            items.Add(new ToolStripMenuItem("Dismount", null, OnDismount) { Enabled = RS232Mounter.diskController.IsMounted(driveIndex), Tag = driveIndex });
            items.Add(new ToolStripMenuItem("Clear", null, OnClearRecentList) { Enabled = anyRecentFiles, Tag = driveIndex });
            if (!anyRecentFiles) return;
            items.Add(new ToolStripSeparator());
            for (int i = Properties.Settings.Default.RecentImages.Count - 1; i >= 0; i--)
            {
                bool isCurrent = currentMountedFile != null && string.Compare(Properties.Settings.Default.RecentImages[i], currentMountedFile, true) == 0;
                items.Add(new ToolStripMenuItem(Properties.Settings.Default.RecentImages[i], null, OnMountRecentFile) { Checked = isCurrent, Tag = driveIndex });
            }
        }

        #region Event handlers

        private static void OnMountFiles(object Sender, EventArgs e)
        {
            MountFiles((int)(Sender as ToolStripMenuItem).Tag);
        }

        private static void OnMountDirectory(object Sender, EventArgs e)
        {
            MountDirectory((int)(Sender as ToolStripMenuItem).Tag);
        }

        private static void OnMountFromClipboard(object sender, EventArgs e)
        {
            MountFromClipboard((int)(sender as ToolStripMenuItem).Tag);
        }

        private static void OnDismount(object Sender, EventArgs e)
        {
            Dismount((int)(Sender as ToolStripMenuItem).Tag);
        }

        private static void OnClearRecentList(object Sender, EventArgs e)
        {
            Properties.Settings.Default.RecentImages.Clear();
        }

        private static void OnMountRecentFile(object Sender, EventArgs e)
        {
            int driveIndex = (int)(Sender as ToolStripMenuItem).Tag;
            string fileName = (Sender as ToolStripMenuItem).Text;
            MountRecentFile(driveIndex, fileName);
        }

        #endregion

        #region Helpers

        private static void UpdateRecentList(string[] fileNames, int driveIndex)
        {
            if (fileNames.Length != 1) return;
            string fileName = fileNames[0];
            int recentFileIndex = Properties.Settings.Default.RecentImages.IndexOf(fileName);
            if (recentFileIndex != -1) Properties.Settings.Default.RecentImages.RemoveAt(recentFileIndex);
            Properties.Settings.Default.RecentImages.Add(fileName);

            Properties.Settings.Default[string.Format("DriveImage{0}", driveIndex)] = fileName;
            if (RS232Mounter.dropForm != null && RS232Mounter.dropForm.Visible) RS232Mounter.dropForm.Invalidate();
        }

        #endregion

        #region Action performers

        internal static void MountFiles(int driveIndex)
        {
            try
            {
                if (RS232Mounter.diskController.IsMounted(driveIndex)) RS232Mounter.diskController.Dismount(driveIndex);
                if (RS232Mounter.diskController.IsMounted(driveIndex)) return;
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.CheckFileExists = true;
                dialog.CheckPathExists = true;
                dialog.DefaultExt = "*.trd";
                dialog.Multiselect = true;
                dialog.Title = "Select Files to mount";
                dialog.Filter = "ZX Spectrum disk images (*.trd, *.scl)|*.trd;*.scl|Hobeta Files (*.$?)|*.$?|Archives (*.zip, *.7z, *.rar)|*.zip;*.7z;*.rar|Binary file(s) (*.*)|*.*";
                if (dialog.ShowDialog() != DialogResult.OK) return;
                string[] selectedFiles = dialog.FileNames;
                if (RS232Mounter.diskController.Mount(driveIndex, selectedFiles))
                    UpdateRecentList(selectedFiles, driveIndex);
                else
                    MessageBox.Show("An error occurred during mounting of files", "Mount Files", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("An error occurred during mounting of files: {0}", ex.Message), "Mount Files", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        internal static void MountDirectory(int driveIndex)
        {
            try
            {
                FolderBrowserDialog dialog = new FolderBrowserDialog();
                dialog.Description = "Select directory to mount";
                dialog.ShowNewFolderButton = false;
                if (dialog.ShowDialog() != DialogResult.OK) return;
                string directoryName = dialog.SelectedPath;
                if (!Directory.Exists(directoryName))
                {
                    MessageBox.Show("Directory does not exists", "Mount Directory", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                };
                string[] filesToMount = new string[] { directoryName };
                if (RS232Mounter.diskController.Mount(driveIndex, filesToMount))
                    UpdateRecentList(filesToMount, driveIndex);
                else
                    MessageBox.Show("An error occurred during mounting of files", "Mount Directory", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("An error occurred during mounting of files: {0}", ex.Message), "Mount Directory", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        internal static void MountFromClipboard(int driveIndex)
        {
            try
            { 
                if (!Clipboard.ContainsText()) { MessageBox.Show("Clipboard does not contains a situable data"); return; }
                string[] fileNames = Clipboard.GetText().Split(new string [] { Environment.NewLine, "\n" }, StringSplitOptions.RemoveEmptyEntries);
                if (fileNames.Length == 0) { MessageBox.Show("Clipboard contains no text"); return; }
                if (RS232Mounter.diskController.Mount(driveIndex, fileNames))
                    UpdateRecentList(fileNames, driveIndex);
                else
                    MessageBox.Show("An error occurred during mounting of files", "Mount Directory", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("An error occurred during mounting of files: {0}", ex.Message), "Mount Directory", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        internal static void Dismount(int driveIndex)
        {
            try
            {
                if (RS232Mounter.diskController.IsMounted(driveIndex)) RS232Mounter.diskController.Dismount(driveIndex);
                if (!RS232Mounter.diskController.IsMounted(driveIndex)) Properties.Settings.Default[string.Format("DriveImage{0}", driveIndex)] = null;
                if (RS232Mounter.dropForm != null && RS232Mounter.dropForm.Visible) RS232Mounter.dropForm.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("An error occurred during dismountond of a drive: {0}", ex.Message), "Dismount Image", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        
        }

        internal static void MountRecentFile(int driveIndex, string fileName)
        {
            try
            {
                if (RS232Mounter.diskController.IsMounted(driveIndex)) RS232Mounter.diskController.Dismount(driveIndex);
                if (RS232Mounter.diskController.IsMounted(driveIndex)) return;
                string[] filesToMount = new string[] { fileName };
                if (RS232Mounter.diskController.Mount(driveIndex, filesToMount))
                    UpdateRecentList(filesToMount, driveIndex);
                else
                    MessageBox.Show("An error occurred during mounting of files", "Mount File", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("An error occurred during mounting of files: {0}", ex.Message), "Mount File", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        
        #endregion
    }
}
