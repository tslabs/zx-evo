﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RS232Mounter.UI
{
    public partial class Log : Form
    {
        public Log()
        {
            InitializeComponent();
            Visible = Properties.Settings.Default.ShowLog;
            logText.ReadOnly = true;
            logText.BackColor = SystemColors.Window;
        }

        delegate void AddMessageToTextControl_Type(string message);

        public void WriteLine(string message)
        {
#if DEBUG
            System.Diagnostics.Debug.WriteLine(message);
#endif
            if (Visible)
            {
                logText.Invoke(new AddMessageToTextControl_Type(AddMessageToTextControl), message);
            }
        }

        private void AddMessageToTextControl(string message)
        {
            logText.Select(int.MaxValue, 0);
            logText.SelectionColor = message.StartsWith("Error", StringComparison.OrdinalIgnoreCase) ? Color.Red : SystemColors.WindowText;
            logText.SelectedText = message + System.Environment.NewLine;
            logText.ScrollToCaret();
        }

        private void Log_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                (sender as Log).Hide();
            }
        }

        private void Log_VisibleChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default.ShowLog = (sender as Log).Visible;
        }
    }
}
