﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;
using System.IO.Ports;
using System.IO;

namespace RS232Mounter.UI
{
    class TrayIcon
    {
        private NotifyIcon icon = new NotifyIcon();

        private void SetupContextMenu()
        {
            ContextMenuStrip menu = new ContextMenuStrip();
            menu.Items.AddRange(new ToolStripItem[]
            {
                new ToolStripMenuItem("Drive A") { Name = "DriveA", Tag = 0 },
                new ToolStripMenuItem("Drive B") { Name = "DriveB", Tag = 1 },
                new ToolStripMenuItem("Drive C") { Name = "DriveC", Tag = 2 },
                new ToolStripMenuItem("Drive D") { Name = "DriveD", Tag = 3 },
                new ToolStripSeparator(),
                new ToolStripMenuItem("Log", null, OnClickLog) { CheckOnClick = true, Name = "Log" },
                new ToolStripMenuItem("Drop Form", null, OnClickShowDropForm) { CheckOnClick = true, Name = "DropForm" },
                new ToolStripSeparator(),
                new ToolStripMenuItem("Port") { Name = "Port" },
                new ToolStripSeparator(),
                new ToolStripMenuItem("Exit", null, OnExit)

            });
            menu.Opening += UpdateContextMenu;
            icon.ContextMenuStrip = menu;
        }

        internal TrayIcon()
        {
            icon.Icon = Icon.FromHandle(Properties.Resources.TrayIcon.GetHicon());
            SetupContextMenu();
            icon.Visible = true;
        }

        private void OnExit(object Sender, EventArgs e)
        {
            icon.Visible = false;
            icon = null;
            Application.Exit();
        }

        private void OnClickLog(object Sender, EventArgs e)
        {
            RS232Mounter.log.Visible = (Sender as ToolStripMenuItem).Checked;
        }

        private void OnClickShowDropForm(object Sender, EventArgs e)
        {
            RS232Mounter.dropForm.Visible = (Sender as ToolStripMenuItem).Checked;
        }

        private void UpdateContextMenu(object Sender, EventArgs e)
        {
            (icon.ContextMenuStrip.Items["Log"] as ToolStripMenuItem).Checked = RS232Mounter.log.Visible;
            
            (icon.ContextMenuStrip.Items["DropForm"] as ToolStripMenuItem).Checked = RS232Mounter.dropForm.Visible;

            string[] existingCOMPorts = TSConfCommunication.TSConfCommunicator.GetCOMPorts();
            ToolStripItemCollection portSubItems = (icon.ContextMenuStrip.Items["Port"] as ToolStripMenuItem).DropDownItems;
            portSubItems.Clear();
            foreach (string portName in existingCOMPorts)
                portSubItems.Add(new ToolStripMenuItem(portName, null, OnSelectPort, portName) { Checked = string.Compare(portName, Properties.Settings.Default.CurrentCOMPort, true) == 0 });

            foreach (ToolStripItem rootMenuItem in icon.ContextMenuStrip.Items)
            {
                if (rootMenuItem.Tag == null) continue;
                ToolStripMenuItem driveItem = rootMenuItem as ToolStripMenuItem;
                int driveIndex = (int)rootMenuItem.Tag;
                driveItem.Checked = RS232Mounter.diskController.IsMounted(driveIndex);
                MountContextMenu.FillMountMenu(driveItem.DropDownItems, driveIndex);
            }
        }

        private void OnSelectPort(object Sender, EventArgs e)
        {
            try
            {
                string portName = (Sender as ToolStripMenuItem).Text;
                Properties.Settings.Default.CurrentCOMPort = portName;
                RS232Mounter.TSConfCommunicator.SelectPort(portName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("An error occurred during open COM port: {0}", ex.Message), "Mount File", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

    }
}
