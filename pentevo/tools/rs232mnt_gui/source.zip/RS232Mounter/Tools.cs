﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RS232Mounter
{
    static class Tools
    {
        internal static int GetDriveIndex(string driveName)
        {
            if (string.IsNullOrEmpty(driveName)) return -1;
            char driveLetter = driveName[driveName.Length - 1];
            return (int)char.ToUpper(driveLetter) - (int)'A';
        }

        internal static bool ArrayContainsString(string[] array, string item)
        {
            foreach (string arrayItem in array)
                if (string.Compare(arrayItem, item, true) == 0) return true;
            return false;
        }
    }
}
