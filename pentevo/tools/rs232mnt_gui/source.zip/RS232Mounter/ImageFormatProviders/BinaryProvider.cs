﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;
using RS232Mounter.ImageFormatProviders.BaseClasses;

namespace RS232Mounter.ImageFormatProviders
{
    internal class BinaryProvider : VirtualTRDProviderBase
    {
        private bool AddPCFile(string fileName)
        {
            string extension = Path.GetExtension(fileName);
            char trdExtenstion = 'C';
            ushort start = 0;
            if (!string.IsNullOrEmpty(extension))
            {
                if (extension.Length > 1) trdExtenstion = extension[1];
                if (extension.Length > 2) start = (byte)extension[2];
                if (extension.Length > 3) start |= (ushort)(((byte)extension[3]) << 8);
            }
            return AddFile(Path.GetFileNameWithoutExtension(fileName), File.ReadAllBytes(fileName), trdExtenstion, start);
        }

        internal override bool PerformMount(string[] fileNames)
        {
            if (!base.PerformMount(fileNames)) return false;
            string diskName = null;
            if (fileNames.Length == 1)
                if (File.Exists(fileNames[0])) diskName = Path.GetFileNameWithoutExtension(fileNames[0]);
                else
                    if (Directory.Exists(fileNames[0])) diskName = Path.GetDirectoryName(fileNames[0]);
            base.Format(diskName);
            bool skipped = false;
            foreach(string item in fileNames)
            {
                if (File.Exists(item))
                    skipped |= !AddPCFile(item);
                else
                    if (Directory.Exists(item))
                        foreach (string directoryFile in Directory.GetFiles(item, "*.*", SearchOption.AllDirectories))
                            skipped |= !AddPCFile(directoryFile);
                    else
                        skipped = true;
            }
            LogWarning("BinaryProvider: Some files were skipped");
            if (skipped)
                MessageBox.Show("One or more files were skipped due to TR-DOS format limitations", "Mount binary files", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return true;
        }
    }
}
