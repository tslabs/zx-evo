﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.IO;
using System.Windows.Forms;

namespace RS232Mounter.ImageFormatProviders.BaseClasses
{
    abstract class ImageFormatProviderBase : IDisposable
    {
        private object locker = new object();
        FileCache fileCache;

        internal bool Mount(FileCache fileCache)
        {
            lock (locker)
            {
                this.fileCache = fileCache;
                if (PerformMount(this.fileCache.GetLocalFileNames()))
                {
                    Log("Mounted:");
                    foreach (string fileName in fileCache.GetOriginalFileNames())
                        Log("\t" + fileName);
                    return true;
                }
                this.fileCache.Clear();
                this.fileCache = null;
                LogError("Mounting failed");
                MessageBox.Show("Mounting failed", "Mount files", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        internal void Dismount()
        {
            lock (locker)
            {
                if (PerformDismount())
                {
                    if (fileCache != null)
                    {
                        this.fileCache.Clear();
                        this.fileCache = null;
                    }
                    Log("Drive was dismounted");
                }
                else
                    Log("Dismount cancelled");
            }
        }

        public virtual void Dispose()
        {
            Dismount();
        }

        internal bool Read(int track, int sector, byte[] data, int offset)
        {
            lock (locker)
            {
                if (IsMounted)
                    return PerformRead(track, sector, data, offset);
                else
                    return false;
            }
        }

        internal void Write(int track, int sector, byte[] data, int offset)
        {
            lock (locker)
            {
                if (IsMounted)
                    PerformWrite(track, sector, data, offset);
            }
        }

        internal bool IsMounted { get { return fileCache != null; } }

        internal string[] FileNames { get { return fileCache.GetLocalFileNames(); } }

        internal void Log(string message)
        {
            RS232Mounter.log.WriteLine(message);
        }
        internal void LogError(string message) { Log(string.Format("Error: {0}", message)); }
        internal void LogWarning(string message) { Log(string.Format("Warning! {0}", message)); }

        internal abstract bool PerformMount(string[] fileNames);
        internal abstract bool PerformDismount();
        internal abstract bool PerformRead(int track, int sector, byte[] data, int offset);
        internal abstract void PerformWrite(int track, int sector, byte[] data, int offset);
        internal abstract int GetSectorSize();
    }
}
