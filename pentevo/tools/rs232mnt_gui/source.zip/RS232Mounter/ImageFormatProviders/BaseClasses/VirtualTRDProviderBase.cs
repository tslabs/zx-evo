﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace RS232Mounter.ImageFormatProviders.BaseClasses
{
    internal class VirtualTRDProviderBase : ImageFormatProviderBase
    {

        #region TRD geomeyty consts

        protected const int SECTOR_LENGTH = 0x100;
        protected const int SECTORS_IN_TRACK = 0x10;
        protected const int TRACK_LENGTH = SECTOR_LENGTH * SECTORS_IN_TRACK;
        protected const int MAX_TRACKS = 160;

        #endregion

        #region TRD format consts

        private const int EIGHT_SECTOR_OFFSET = 8 * SECTOR_LENGTH;
        private const int FIRST_FREE_SECTOR = EIGHT_SECTOR_OFFSET + 0xe1;
        private const int FIRST_FREE_TRACK = EIGHT_SECTOR_OFFSET + 0xe2;
        private const int DISK_TYPE = EIGHT_SECTOR_OFFSET + 0xe3;
        private const int FILES_COUNT = EIGHT_SECTOR_OFFSET + 0xe4;
        private const int FREE_SECTORS = EIGHT_SECTOR_OFFSET + 0xe5;
        private const int TRD_ID = EIGHT_SECTOR_OFFSET + 0xe7;
        private const int SPACE = EIGHT_SECTOR_OFFSET + 0xea;
        private const int SPACE_LENGTH = 0x09;
        private const int DELETED_FILES = EIGHT_SECTOR_OFFSET + 0xf4;
        private const int DISK_NAME = EIGHT_SECTOR_OFFSET + 0xf5;

        #endregion

        private bool DirtyFlag = false;

        private byte[] image;

        protected bool Format(string diskName = null, int tracks = 160)
        {
            if (diskName == null) diskName = "Mounted";
            if (tracks < 2 || tracks > MAX_TRACKS)
            {
                LogError(string.Format("Invalid image size. Must be 2..{0} tracks", MAX_TRACKS));
                return false;
            }
            image = new byte[tracks * TRACK_LENGTH];
            image[FIRST_FREE_SECTOR] = 0x00;
            image[FIRST_FREE_TRACK] = 0x01;
            image[DISK_TYPE] = 0x16;
            image[FILES_COUNT] = 0x00;
            int freeSectors = (tracks - 1) * 0x10;
            image[FREE_SECTORS] = (byte)(freeSectors & 0xff);
            image[FREE_SECTORS + 1] = (byte)((freeSectors >> 8) & 0xff);
            image[TRD_ID] = 0x10;
            for (int i = 0;  i < SPACE_LENGTH; i++)
                image[SPACE + i] = 0x20;
            image[DELETED_FILES] = 0x00;
            for (int i = 0; i < 8; i++)
                image[DISK_NAME + i] = (i < diskName.Length) ? (byte)(diskName[i]) : (byte)0x20;
            return true;
        }

        protected bool LoadImage(string PCFileName)
        {
            if (string.IsNullOrEmpty(PCFileName) || !File.Exists(PCFileName)) { LogError("Load TRD image: File name is empty or file does not exists"); return false; }
            image = File.ReadAllBytes(PCFileName);
            return true;
        }

        private bool AddLargeFile(string PCFileName, char extension, byte[] data)
        {
            int position = 0;
            string trdFileName = PCFileName.TrimEnd(' ');
            if (trdFileName.Length > 6) trdFileName = trdFileName.Substring(0, 6);
            trdFileName += "{0:D2}";
            int trdFileIndex = 0;
            while (position < data.Length)
            {
                int trdFileLength = Math.Min(data.Length - position, 0xff * SECTOR_LENGTH);
                byte[] trdFileContent = new byte[trdFileLength];
                Array.Copy(data, trdFileContent, trdFileLength);
                if (!AddFile(string.Format(trdFileName, trdFileIndex), trdFileContent, extension)) return false;
                trdFileIndex++;
                position += trdFileLength;
            }
            return true;
        }

        protected bool AddFile(string PCFileName, byte[] data, char? extension = null, ushort start = 0, ushort? lentgh = null, byte? sizeInSectors = null)
        {
            if (image == null) { LogError("Image is not formatted"); return false; }
            if (string.IsNullOrEmpty(PCFileName)) { LogError("Add File: File name is empty"); return false; }
            if (image[FILES_COUNT] >= 0x80) { LogWarning("Add File: No room in directory"); return false; }

            int freeSectors = 0x100 * image[FREE_SECTORS + 1] + image[FREE_SECTORS];
            byte fileSizeInSectors = (byte)(data.Length >> 8);
            if ((data.Length & 0xff) != 0x00) fileSizeInSectors++;
            if (freeSectors < fileSizeInSectors) { LogWarning("Add File: No room on disk"); return false; }
            int startPosition = image[FIRST_FREE_TRACK] * TRACK_LENGTH + image[FIRST_FREE_SECTOR] * SECTOR_LENGTH;
            if ((startPosition + data.Length) > image.Length) { LogWarning("Add File: No room on disk"); return false; }
            
            if (PCFileName.Length > 8) PCFileName = PCFileName.Substring(0, 8);
            if (!extension.HasValue) extension = 'C';

            if (data.Length > 0xff * 0x100) return AddLargeFile(PCFileName, extension.Value, data);

            Buffer.BlockCopy(data, 0, image, startPosition, data.Length); // Copy data
            
            int fileHeaderPosition = 0x10 * image[FILES_COUNT];
            ushort directoryLength = lentgh ?? (ushort)data.Length;
            
            for (int i = 0; i < 8; i++)
                image[fileHeaderPosition + i] = (i < PCFileName.Length) ? (byte)(PCFileName[i]) : (byte)0x20;
            image[fileHeaderPosition + 0x08] = (byte)extension;
            image[fileHeaderPosition + 0x09] = (byte)(start & 0xff);
            image[fileHeaderPosition + 0x0a] = (byte)((start >> 8) & 0xff);
            image[fileHeaderPosition + 0x0b] = (byte)(directoryLength & 0xff);
            image[fileHeaderPosition + 0x0c] = (byte)((directoryLength >> 8) & 0xff);
            image[fileHeaderPosition + 0x0d] = sizeInSectors ?? fileSizeInSectors;
            image[fileHeaderPosition + 0x0e] = image[FIRST_FREE_SECTOR];
            image[fileHeaderPosition + 0x0f] = image[FIRST_FREE_TRACK];

            int sectorAfterFile = image[FIRST_FREE_SECTOR] + image[FIRST_FREE_TRACK] * 0x10 + fileSizeInSectors;
            image[FIRST_FREE_SECTOR] = (byte)(sectorAfterFile & 0x0f);
            image[FIRST_FREE_TRACK] = (byte)((sectorAfterFile >> 4) & 0xff);

            freeSectors -= fileSizeInSectors;
            image[FREE_SECTORS] = (byte)(freeSectors & 0xff);
            image[FREE_SECTORS + 1] = (byte)((freeSectors >> 8) & 0xff);
            image[FILES_COUNT]++;
            return true;
        }

        internal override bool PerformMount(string[] fileNames)
        {
            DirtyFlag = false;
            return true;
        }

        internal override bool PerformDismount()
        {
            bool dismount = true;
            if (DirtyFlag)
            {
                DialogResult userSaveAnswer = MessageBox.Show("Image was modified. Are you want to save it as *.trd image?", "Dismount Image", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (userSaveAnswer == DialogResult.Cancel) return false;
                if (userSaveAnswer == DialogResult.Yes)
                {
                    SaveFileDialog saveDialog = new SaveFileDialog();
                    saveDialog.Title = "Save Image as *.trd file";
                    saveDialog.AddExtension = true;
                    saveDialog.CheckPathExists = true;
                    saveDialog.DefaultExt = "trd";
                    saveDialog.Filter = "TRD disk image|*.trd";
                    if (FileNames.Length == 1)
                    {
                        saveDialog.InitialDirectory = Path.GetDirectoryName(FileNames[0]);
                        if (File.Exists(FileNames[0]))
                            saveDialog.FileName = Path.GetFileNameWithoutExtension(FileNames[0]);
                        else
                            if (Directory.Exists(FileNames[0]))
                                saveDialog.FileName = Path.GetDirectoryName(FileNames[0]);
                            else
                                saveDialog.FileName = "MultiFile";
                    }
                    else
                    {
                        saveDialog.InitialDirectory = System.Environment.GetEnvironmentVariable("UserProfile");
                        saveDialog.FileName = "MultiFile";
                    };
                    saveDialog.OverwritePrompt = true;
                    saveDialog.ValidateNames = true;
                    if (saveDialog.ShowDialog() == DialogResult.OK)
                        File.WriteAllBytes(saveDialog.FileName, image);
                    else
                        dismount = false;
                };
            }
            if (dismount) image = null;
            return dismount;
        }

        internal override bool PerformRead(int track, int sector, byte[] data, int offset)
        {
            Buffer.BlockCopy(image, track * TRACK_LENGTH + sector * SECTOR_LENGTH, data, offset, SECTOR_LENGTH);
            return true;
        }

        internal override void PerformWrite(int track, int sector, byte[] data, int offset)
        {
            Buffer.BlockCopy(data, offset, image, track * TRACK_LENGTH + sector * SECTOR_LENGTH, SECTOR_LENGTH);
            DirtyFlag = true;
        }

        internal override int GetSectorSize()
        {
            return SECTOR_LENGTH;
        }

        protected long GetFreeSpace()
        {
            return (image[FREE_SECTORS] + (image[FREE_SECTORS + 1] << 8)) * SECTOR_LENGTH;
        }

        protected long GetFilesCount()
        {
            return image[FILES_COUNT];
        }

    }
}
