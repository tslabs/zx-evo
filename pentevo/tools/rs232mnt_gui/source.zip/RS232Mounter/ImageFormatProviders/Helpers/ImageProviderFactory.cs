﻿using System;
using System.Collections.Generic;
using System.Text;
using RS232Mounter.ImageFormatProviders;
using System.IO;
using RS232Mounter.ImageFormatProviders.BaseClasses;

namespace RS232Mounter.ImageFormatProviders.Helpers
{
    internal static class ImageProviderFactory
    {
        public static ImageFormatProviderBase GetProviderForFile(string[] fileNames)
        {
            if (fileNames.Length == 0) return null;
            bool allEmpty = true;
            foreach (string fileName in fileNames)
                if (!string.IsNullOrEmpty(fileName))
                {
                    allEmpty = false;
                    break;
                }
            if (allEmpty) return null;
            if (SCLProvider.CheckFormat(fileNames)) return new SCLProvider();
            if (TRDProvider.CheckFormat(fileNames)) return new TRDProvider();
            if (HobetaProvider.CheckFormat(fileNames)) return new HobetaProvider();
            if (ArchiveProvider.CheckFormat(fileNames)) return new ArchiveProvider();
            return new BinaryProvider();
        }
    }
}
