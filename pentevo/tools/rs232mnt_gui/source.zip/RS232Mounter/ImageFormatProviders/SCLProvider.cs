﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using RS232Mounter.ImageFormatProviders.BaseClasses;

namespace RS232Mounter.ImageFormatProviders
{
    internal class SCLProvider : VirtualTRDProviderBase
    {
        private class SCLFileInfo
        {
            private byte[] headerData;

            internal string name
            {
                get
                {
                    char[] name = new char[8];
                    for (int i = 0; i < 8; i++)
                        name[i] = (char)(headerData[i]);
                    return new string(name);
                }
            }
            internal char extension { get { return (char)headerData[8]; } }

            internal ushort start { get { return (ushort)(headerData[0x09] + (headerData[0x0a] << 8)); } }
            internal ushort length { get { return (ushort)(headerData[0x0b] + (headerData[0x0c] << 8)); } }
            internal byte lengthInSectors { get { return headerData[0x0d]; } }

            internal SCLFileInfo(byte[] headerData) { this.headerData = headerData; }

        }

        private string fileName;

        internal override bool PerformMount(string[] fileNames)
        {
            if (!base.PerformMount(fileNames)) return false;
            if (fileNames.Length > 1) { Log("SCLProvider: Unable to mount multiple files"); return false; }
            fileName = fileNames[0];
            if (string.IsNullOrEmpty(fileName) || !File.Exists(fileName)) { LogError("SCLProvider: image file does not exists"); return false; }
            
            Format(Path.GetFileNameWithoutExtension(fileName));
            if (new FileInfo(fileName).Length < 9) return false;
            using (BinaryReader reader = new BinaryReader(new FileStream(fileName, FileMode.Open, FileAccess.Read)))
            {
                reader.ReadBytes(8); // Skip signature
                int filesCount = reader.ReadByte();
                SCLFileInfo[] imageInfo = new SCLFileInfo[filesCount];
                for (int i = 0; i < filesCount; i++)
                    imageInfo[i] = new SCLFileInfo(reader.ReadBytes(0x0e));
                for (int i = 0; i < filesCount; i++)
                    AddFile(imageInfo[i].name, reader.ReadBytes(imageInfo[i].lengthInSectors * 0x100), imageInfo[i].extension, imageInfo[i].start, imageInfo[i].length);
                return true;
            }
        }

        internal static bool CheckFormat(string[] fileNames)
        {
            if (fileNames.Length != 1) return false;
            string fileName = fileNames[0];
            if (string.IsNullOrEmpty(fileName) || !File.Exists(fileName)) return false;
            if (new FileInfo(fileName).Length < 9) return false;
            byte[] signature = new byte[8];
            using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read))
                fs.Read(signature, 0, 8);
            return System.Text.Encoding.ASCII.GetString(signature) == "SINCLAIR";
        }

        internal override bool PerformDismount()
        {
            fileName = null;
            return base.PerformDismount();
        }
    }
}
