﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using RS232Mounter.ImageFormatProviders.BaseClasses;

namespace RS232Mounter.ImageFormatProviders
{


    class TRDProvider : ImageFormatProviderBase
    {
        private const int SECTOR_LENGTH = 0x100;
        private const int SECTORS_IN_TRACK = 0x10;
        private const int TRACK_LENGTH = SECTOR_LENGTH * SECTORS_IN_TRACK;

        private string fileName;
        
        internal override bool PerformMount(string[] fileNames)
        {
            if (fileNames.Length > 1) { LogError("TRDProvider:  Unable to mount more that one file"); return false; }
            fileName = fileNames[0];
            if (!File.Exists(fileName)) { LogError(string.Format("TRDProvider: File {0} does not exists", fileName)); return false; }
            return true;
        }

        internal static bool CheckFormat(string[] fileNames)
        {
            if (fileNames.Length != 1) return false;
            string fileName = fileNames[0];
            if (!File.Exists(fileName)) return false;
            if (new FileInfo(fileName).Length % TRACK_LENGTH != 0) return false;
            using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                fs.Position = 0 * TRACK_LENGTH + 8 * SECTOR_LENGTH + 0xe7;
                if (fs.ReadByte() != 0x10) return false;
            }
            return true;
        }

        internal override bool PerformRead(int track, int sector, byte[] data, int offset)
        {
            if (fileName == null || !File.Exists(fileName)) return false;
            using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                fs.Position = track * TRACK_LENGTH + sector * SECTOR_LENGTH;
                return fs.Read(data, offset, SECTOR_LENGTH) == SECTOR_LENGTH;
            }
        }

        internal override void PerformWrite(int track, int sector, byte[] data, int offset)
        {
            if (fileName == null || !File.Exists(fileName)) return;
            using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Write))
            {
                fs.Position = track * TRACK_LENGTH + sector * SECTOR_LENGTH;
                fs.Write(data, offset, SECTOR_LENGTH);
            }
        }

        internal override bool PerformDismount()
        {
            fileName = null;
            return true;
        }

        internal override int GetSectorSize()
        {
            return SECTOR_LENGTH;
        }

        public override void Dispose()
        {
            Dismount();
        }
    }
}
