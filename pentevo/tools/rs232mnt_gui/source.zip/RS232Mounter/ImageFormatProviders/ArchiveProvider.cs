﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.IO.Compression;
using System.Text.RegularExpressions;
using System.Diagnostics;
using RS232Mounter.ImageFormatProviders.BaseClasses;

namespace RS232Mounter.ImageFormatProviders
{
    internal class ArchiveProvider : ImageFormatProviderBase
    {
        private enum ArchiveFormats
        {
            Zip,
            RAR,
            SevenZ,
            Unknown
        }

        private ImageFormatProviderBase underlyingProvider;
        private string extractedFilesDirectory = null;
        private string fileName;

        internal static bool CheckFormat(string[] fileNames)
        {
            if (fileNames.Length != 1) return false;
            return DetectFormat(fileNames[0]) != ArchiveFormats.Unknown;
        }

        private static ArchiveFormats DetectFormat(string fileName)
        {
            if (!File.Exists(fileName)) return ArchiveFormats.Unknown;
            byte[] first6Bytes = new byte[6];
            int readBytes = 0;
            using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read))
                readBytes = fs.Read(first6Bytes, 0, 6);
            if (readBytes < 4) return ArchiveFormats.Unknown;
            switch (first6Bytes[0])
            {
                case 0x52: return (first6Bytes[1] == 0x61 && first6Bytes[2] == 0x72 && first6Bytes[3] == 0x21 && first6Bytes[4] == 0x1a && first6Bytes[5] == 0x07) ? ArchiveFormats.RAR : ArchiveFormats.Unknown;
                case 0x37: return (first6Bytes[1] == 0x7a && first6Bytes[2] == 0xbc && first6Bytes[3] == 0xaf && first6Bytes[4] == 0x27 && first6Bytes[5] == 0x1c) ? ArchiveFormats.SevenZ : ArchiveFormats.Unknown;
                case 0x50: return (first6Bytes[1] == 0x4b && first6Bytes[2] == 0x03 && first6Bytes[3] == 0x04) ? ArchiveFormats.Zip : ArchiveFormats.Unknown;
                default: return ArchiveFormats.Unknown;
            }
        }

        private bool UnZipArchive()
        {
            try
            {
                if (!Directory.Exists(extractedFilesDirectory)) Directory.CreateDirectory(extractedFilesDirectory);
                ZipStorer archive = ZipStorer.Open(fileName, FileAccess.Read);
                foreach (ZipStorer.ZipFileEntry zippedFile in archive.ReadCentralDir())
                {
                    if (zippedFile.FileSize == 0) continue;
                    string fullDestinationFileName = Path.Combine(extractedFilesDirectory, zippedFile.FilenameInZip);
                    string destinationFileDirectory = Path.GetDirectoryName(fullDestinationFileName);
                    if (!Directory.Exists(destinationFileDirectory)) Directory.CreateDirectory(destinationFileDirectory);
                    using (FileStream destinationFileStream = new FileStream(fullDestinationFileName, FileMode.CreateNew, FileAccess.Write))
                        archive.ExtractFile(zippedFile, destinationFileStream);
                }
                return true;
            }
            catch(Exception ex)
            {
                RS232Mounter.log.WriteLine(string.Format("Erorr: Unable to unzip the file {0}: {1}", fileName, ex.Message));
                if (Directory.Exists(extractedFilesDirectory)) Directory.Delete(extractedFilesDirectory, true);
                return false;
            }
                                
        }
            
        private bool unpackWithExternalUnpacker(string unpackerExeFileName, string commandLineArgs)
        {
            if (!File.Exists(unpackerExeFileName)) return false;
            if (!Directory.Exists(extractedFilesDirectory)) Directory.CreateDirectory(extractedFilesDirectory);
            ProcessStartInfo unrarProcessStartupInfo = new ProcessStartInfo()
            {
                FileName = unpackerExeFileName,
                Arguments = commandLineArgs,
                WindowStyle = ProcessWindowStyle.Hidden
            };
            Process unRarProcess = Process.Start(unrarProcessStartupInfo);
            unRarProcess.WaitForExit();
            return unRarProcess.ExitCode == 0;
        }

        private bool UnRARArchive()
        {
            try
            {
                string winRarCommandLine = (string)Microsoft.Win32.Registry.GetValue(@"HKEY_CLASSES_ROOT\WinRAR\shell\open\command", null, null);
                if (string.IsNullOrEmpty(winRarCommandLine)) return false;

                string winRarPath = winRarCommandLine;
                if (winRarPath.EndsWith(" \"%1\"")) winRarPath = winRarPath.Substring(0, winRarPath.IndexOf(" \"%1\""));
                winRarPath = winRarPath.Trim('"');
                string unRarPath = Path.Combine(Path.GetDirectoryName(winRarPath), "unrar.exe");
                return unpackWithExternalUnpacker(unRarPath, string.Format("x \"{0}\" \"{1}\\\"", fileName, extractedFilesDirectory));
            }
            catch (Exception ex)
            {
                if (Directory.Exists(extractedFilesDirectory)) Directory.Delete(extractedFilesDirectory, true);
                RS232Mounter.log.WriteLine(string.Format("Erorr: Unable to unrar the file {0}: {1}", fileName, ex.Message));
                return false;
            }
        }

        private bool Un7ZArchive()
        {
            try
            {
                string sevenZInstallPath = (string)Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\Software\7-Zip", "Path", null);
                if (string.IsNullOrEmpty(sevenZInstallPath)) return false;

                string sevenZPath = Path.Combine(sevenZInstallPath, "7z.exe");
                return unpackWithExternalUnpacker(sevenZPath, string.Format("x \"{0}\" -o\"{1}\\\"", fileName, extractedFilesDirectory));
            }
            catch (Exception ex)
            {
                if (Directory.Exists(extractedFilesDirectory)) Directory.Delete(extractedFilesDirectory, true);
                RS232Mounter.log.WriteLine(string.Format("Erorr: Unable to un7z the file {0}: {1}", fileName, ex.Message));
                return false;
            }
        }

        private bool ExtractArchive(ArchiveFormats format)
        {
            switch (format)
            {
                case (ArchiveFormats.Zip): return UnZipArchive() || Un7ZArchive() || UnRARArchive();
                case (ArchiveFormats.SevenZ): return  Un7ZArchive() || UnRARArchive() || UnZipArchive();
                case (ArchiveFormats.RAR): return UnRARArchive() || Un7ZArchive() || UnZipArchive();
                default: return false;
            }
        }

        internal override bool PerformMount(string[] fileNames)
        {

            if (fileNames.Length != 1) { LogError("ArchiveProvider: Unable to mount multiple files or missing file"); return false; }
            fileName = fileNames[0];
            if (string.IsNullOrEmpty(fileName) || !File.Exists(fileName)) { Log(string.Format("ArchiveProvider: The file {0} does not exists", fileName)); return false; }
            
            ArchiveFormats format = DetectFormat(fileName);
            if (format == ArchiveFormats.Unknown) { LogError("ArchiveProvider: Unsupported archive format"); return false; }
            extractedFilesDirectory = Path.Combine(Path.GetTempPath(), Path.GetFileNameWithoutExtension(fileName));
            if (Directory.Exists(extractedFilesDirectory)) Directory.Delete(extractedFilesDirectory, true);
            if (!ExtractArchive(format)) return false;
            
            string lastKnownImageFileName = null;
            int TRDFilesCount = 0;
            int SCLFilesCount = 0;
            string[] unpackedFileNames = Directory.GetFiles(extractedFilesDirectory, "*.*", SearchOption.AllDirectories);
            if (unpackedFileNames.Length == 0) return false;
            foreach (string extractedFileName in unpackedFileNames)
            {
                if (TRDProvider.CheckFormat(new string[] { extractedFileName })) { TRDFilesCount++; lastKnownImageFileName = extractedFileName; };
                if (SCLProvider.CheckFormat(new string[] { extractedFileName })) { SCLFilesCount++; lastKnownImageFileName = extractedFileName; };
            }
            if (TRDFilesCount + SCLFilesCount == 1)
            {
                if (TRDFilesCount == 1)
                    underlyingProvider = new CachedTRDProvider();
                else
                    underlyingProvider = new SCLProvider();
                return underlyingProvider.PerformMount(new string[] { lastKnownImageFileName });
            };
            underlyingProvider = new BinaryProvider();
            return underlyingProvider.PerformMount(unpackedFileNames);
        }

        internal override bool PerformDismount()
        {
            if (underlyingProvider != null && !underlyingProvider.PerformDismount()) return false;
            fileName = null;
            if (extractedFilesDirectory != null && Directory.Exists(extractedFilesDirectory)) Directory.Delete(extractedFilesDirectory, true);
            return true;
        }

        internal override bool PerformRead(int track, int sector, byte[] data, int offset)
        {
            if (underlyingProvider == null) return false;
            return underlyingProvider.PerformRead(track, sector, data, offset);
        }

        internal override void PerformWrite(int track, int sector, byte[] data, int offset)
        {
            if (underlyingProvider != null) underlyingProvider.PerformWrite(track, sector, data, offset);
        }

        public override void Dispose()
        {
            if (PerformDismount())
                base.Dispose();
        }

        internal override int GetSectorSize()
        {
            return underlyingProvider.GetSectorSize();
        }
    }
}
