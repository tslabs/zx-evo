﻿using System;
using System.Collections.Generic;
using System.Text;
using RS232Mounter.ImageFormatProviders.BaseClasses;
using System.IO;

namespace RS232Mounter.ImageFormatProviders
{
    internal class HobetaProvider : VirtualTRDProviderBase
    {
        internal override bool PerformMount(string[] fileNames)
        {
            if (!base.PerformMount(fileNames)) return false;
            if (fileNames.Length != 1) { LogError("HobetaProvider: Unable to mount multiple files"); return false; }
            string fileName = fileNames[0];
            if (string.IsNullOrEmpty(fileName) || !File.Exists(fileName)) { LogError("HobetaProvider: File does not exists"); return false; }
            Format(Path.GetFileNameWithoutExtension(fileName));
            using (BinaryReader reader = new BinaryReader(new FileStream(fileName, FileMode.Open, FileAccess.Read)))
            {
                string trdFileName = System.Text.Encoding.ASCII.GetString(reader.ReadBytes(8));
                char extension = (char)reader.ReadByte();
                ushort start = reader.ReadUInt16();
                ushort trdosLength = reader.ReadUInt16();
                ushort sizeInSectors = reader.ReadUInt16();
                reader.ReadUInt16(); // Skip CRC
                return AddFile(trdFileName, reader.ReadBytes((int)(reader.BaseStream.Length - reader.BaseStream.Position)), extension, start, trdosLength, (byte)(sizeInSectors >> 8));
            };
        }

        public static bool CheckFormat(string[] fileNames)
        {
            if (fileNames.Length != 1) return false;
            string fileName = fileNames[0];
            if (string.IsNullOrEmpty(fileName) || !File.Exists(fileName)) return false;
            string extension = Path.GetExtension(fileName);
            if (new FileInfo(fileName).Length > 0xff * TRACK_LENGTH) return false;
            using (BinaryReader reader = new BinaryReader(new FileStream(fileName, FileMode.Open, FileAccess.Read)))
            {
                byte[] header = reader.ReadBytes(15);
                ushort fileCRC = reader.ReadUInt16();
                int CRC = 0;
                for (int i = 0; i <= 14; i++) CRC += header[i] * 257 + i;
                if ((ushort)CRC != fileCRC) return false;
            }
            return true;
        }
    }
}
