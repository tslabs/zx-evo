﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using RS232Mounter.ImageFormatProviders.BaseClasses;

namespace RS232Mounter.ImageFormatProviders
{
    internal class CachedTRDProvider : VirtualTRDProviderBase
    {
        internal override bool PerformMount(string[] fileNames)
        {
            if (fileNames.Length != 1 || !File.Exists(fileNames[0])) { LogError("CachedTRDProvider: Multiple files or file does not exists"); return false; }
            if (!base.PerformMount(fileNames)) return false;
            return base.LoadImage(fileNames[0]);
        }
    }
}
